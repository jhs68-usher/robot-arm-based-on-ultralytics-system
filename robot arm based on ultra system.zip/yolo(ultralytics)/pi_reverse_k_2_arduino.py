import serial
import time
import math
import cv2 as cv
import numpy as np
from ultralytics import YOLO
cap=cv.VideoCapture(0, cv.CAP_OBSENSOR)             #connect to specific depth camera
ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=1)
atan=math.atan()
asin=math.asin()
acos=math.acos()
pi=math.pi
tan=math.tan()
A1=188
A2=220
A3=190
A4=180
alpha=pi/6
x=float()
y=float()
z=float()
#depth camea using programme
color =0
depth=0
depth8U=0
while True:
    if cap.grab()>0:
        retval1, color = cap.retrieve(color, cv.CAP_OBSENSOR_BGR_IMAGE)
        if retval1:
            cv.imshow("color",color)
#color img
        retval2,depth =cap.retrieve(depth,cv.CAP_OBSENSOR_DEPTH_MAP)
        if retval2:
            fsize = depth.shape
            print(depth[int(fsize[0]/2),int(fsize[1]/2)])                   #unit:mm
            depth8U= depth*255.0/4000
            depth8U = np.clip(depth8U,0,255)
            depth8U = np.uint8(depth8U)         #convert depth(read by depth_camera) to straight line distance(true using ) 
            cv.imshow(depth8U)
            
            model=YOLO("best.pt")                       #path problem still need to adjust(targeting the specific trainning model we use)
            results=model.yolov8n.yaml
            def getRes(results):
                res={}
                for r in results:
                    for i, detection in enumerate(r.boxs.xymh):
                        label = r.names[int(r.boxes.cls[i])]
                        x=int(detection[0].item())
                        y=int(detection[1].item())
                        if label not in res:
                            res[label]=[]
                        res[label].append((x,y))
                return res                              #same function as above(but print x,y with yolo & cv, then give these data to the following calculation of j1~4)
            #positoning reverse kinamitcs calculate
            j1=atan(y/x)
            j2 = 2*atan((((8*(A2^2*A3*(x^2 + y^2)^(1/2) - 2*A2^2*A3*A4*tan(alpha/2)^3 + 2*A2^2*A3*tan(alpha/2)^2*(x^2 + y^2)^(1/2) + A2^2*A3*tan(alpha/2)^4*(x^2 + y^2)^(1/2) - 2*A2^2*A3*A4*tan(alpha/2)))/((tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 + 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2)*(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z + 2*A2*z - 2*A4*z + A1^2*tan(alpha/2)^2 + A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 + A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 - 2*A1*A2 + 2*A1*A4 - 2*A2*A4 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A2*tan(alpha/2)^2 - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A4*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A2*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2)) + (4*(-(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 - 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 - 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2)*(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 + 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2))^(1/2)*(A2*A3 + A2*A3*tan(alpha/2)^2))/((tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 + 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2)*(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z + 2*A2*z - 2*A4*z + A1^2*tan(alpha/2)^2 + A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 + A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 - 2*A1*A2 + 2*A1*A4 - 2*A2*A4 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A2*tan(alpha/2)^2 - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A4*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A2*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2)))*(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 + 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2))/(4*(A2*A3 + A2*A3*tan(alpha/2)^2)))
            j3 =-2*atan((-(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 - 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 - 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2)*(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 + 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2))^(1/2)/(tan(alpha/2)^2*(x^2 + y^2) - 2*A1*z - 2*A4*z + A1^2*tan(alpha/2)^2 - A2^2*tan(alpha/2)^2 - A3^2*tan(alpha/2)^2 + A4^2*tan(alpha/2)^2 + A1^2 - A2^2 - A3^2 + A4^2 + z^2*tan(alpha/2)^2 + x^2 + y^2 + z^2 + 2*A1*A4 + 2*A2*A3 - 4*A4*tan(alpha/2)*(x^2 + y^2)^(1/2) - 2*A1*A4*tan(alpha/2)^2 + 2*A2*A3*tan(alpha/2)^2 - 2*A1*z*tan(alpha/2)^2 + 2*A4*z*tan(alpha/2)^2))
            j4=alpha-j2-j3
            #j1-4 are in radian system
            j1 = j1*180/pi
            j2 = j2*180/pi
            j3 = j3*180/pi
            j4 = j4*180/pi

            ser.write(j1,j2,j3,j4)
            time.sleep(10)
            ser.close()
    if cv.pollKey() >=0:
        break
cap.release()
